LANDING PAGE PROJECTS

1. coffee-shop/
   - index.html
   - style.css
   - script.js
   Landing page coffee shop "Kopi Senja": navbar, hero, menu dengan filter kategori,
   slider ulasan, lokasi, footer, dan navigasi responsif.

2. katalog-hmp-ti/
   - index.html
   - style.css
   - script.js
   Katalog digital empat unit usaha HMP-TI ITS: F&B, Percetakan & Dokumen,
   Konsinyasi, dan Jasa Kreatif. Ada modal detail, navigasi responsif, dan CTA.

CARA MENJALANKAN
- Ekstrak ZIP.
- Buka folder proyek yang diinginkan.
- Klik dua kali index.html atau jalankan dengan ekstensi Live Server di VS Code.
- Pastikan koneksi internet tersedia untuk Google Fonts dan gambar Unsplash.

CATATAN PENTING
- Konten alamat, jam operasional, harga, rating, kontak, dan detail layanan yang belum
  diberikan merupakan data contoh/dummy. Ganti dengan data resmi sebelum dipublikasikan.
- Gambar dimuat dari Unsplash sehingga membutuhkan koneksi internet.
- Tidak menggunakan framework; hanya HTML, CSS, dan JavaScript dasar.
