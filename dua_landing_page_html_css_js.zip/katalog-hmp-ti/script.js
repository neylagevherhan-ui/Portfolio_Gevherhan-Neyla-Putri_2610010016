const toggle = document.querySelector(".nav-toggle");
const navMenu = document.querySelector(".nav-menu");
toggle.addEventListener("click", () => {
  const open = navMenu.classList.toggle("open");
  toggle.setAttribute("aria-expanded", open);
  toggle.textContent = open ? "×" : "☰";
});
document.querySelectorAll(".nav-menu a").forEach(link => link.addEventListener("click", () => {
  navMenu.classList.remove("open");
  toggle.setAttribute("aria-expanded", "false");
  toggle.textContent = "☰";
}));

// Konten detail untuk masing-masing unit usaha.
const unitDetails = {
  fnb: {
    title: "Food & Drink",
    description: "Unit F&B menyediakan pilihan makanan dan minuman untuk mendukung kebutuhan mahasiswa selama beraktivitas di lingkungan kampus.",
    note: "Contoh layanan: makanan ringan, makanan berat, kopi, dan minuman segar. Produk, harga, serta jam layanan dapat dikonfirmasi kepada pengelola."
  },
  print: {
    title: "Percetakan & Dokumen",
    description: "Layanan untuk membantu kebutuhan perkuliahan dan organisasi, mulai dari mencetak dokumen hingga pengetikan.",
    note: "Contoh layanan: print hitam putih/warna, fotokopi, dan pengetikan dokumen. Tarif dan format berkas mengikuti ketentuan pengelola."
  },
  consign: {
    title: "Konsinyasi",
    description: "Fasilitas titip jual yang membantu mahasiswa memasarkan produk atau barang kepada lingkungan kampus.",
    note: "Mahasiswa yang ingin menitipkan produk dapat menghubungi pengelola untuk mengetahui syarat, mekanisme bagi hasil, dan ketersediaan tempat."
  },
  creative: {
    title: "Jasa Kreatif",
    description: "Layanan kreatif untuk membantu kebutuhan visual dan dokumentasi kegiatan, baik personal maupun organisasi.",
    note: "Contoh layanan: desain grafis, fotografi, dan videografi. Brief, jadwal, portofolio, serta biaya dapat dibicarakan dengan pengelola."
  }
};
const modal = document.getElementById("modal");
const modalTitle = document.getElementById("modal-title");
const modalDescription = document.getElementById("modal-description");
const modalNote = document.getElementById("modal-note");
document.querySelectorAll(".detail-button").forEach(button => {
  button.addEventListener("click", () => {
    const detail = unitDetails[button.dataset.unit];
    modalTitle.textContent = detail.title;
    modalDescription.textContent = detail.description;
    modalNote.textContent = detail.note;
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
    document.querySelector(".modal-close").focus();
  });
});
function closeModal() {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
}
document.querySelector(".modal-close").addEventListener("click", closeModal);
modal.addEventListener("click", event => { if (event.target === modal) closeModal(); });
document.addEventListener("keydown", event => { if (event.key === "Escape") closeModal(); });
document.getElementById("year").textContent = new Date().getFullYear();
