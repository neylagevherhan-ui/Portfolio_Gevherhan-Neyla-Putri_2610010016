const navToggle = document.querySelector(".nav-toggle");
const navLinks = document.querySelector(".nav-links");
navToggle.addEventListener("click", () => {
  const opened = navLinks.classList.toggle("open");
  navToggle.setAttribute("aria-expanded", opened);
  navToggle.textContent = opened ? "×" : "☰";
});
document.querySelectorAll(".nav-links a").forEach(link => link.addEventListener("click", () => {
  navLinks.classList.remove("open");
  navToggle.setAttribute("aria-expanded", "false");
  navToggle.textContent = "☰";
}));

// Filter menu berdasarkan kategori.
const filterButtons = document.querySelectorAll(".filter-btn");
const menuCards = document.querySelectorAll(".menu-card");
filterButtons.forEach(button => {
  button.addEventListener("click", () => {
    filterButtons.forEach(item => item.classList.remove("active"));
    button.classList.add("active");
    const category = button.dataset.filter;
    menuCards.forEach(card => {
      card.hidden = category !== "all" && card.dataset.category !== category;
    });
  });
});

// Slider ulasan sederhana.
const reviews = [
  { text: "“Tempatnya nyaman, kopinya enak, dan cocok banget buat ngobrol atau menyelesaikan tugas.”", name: "Aditya N.", initials: "AN" },
  { text: "“Suasananya hangat dan pilihan minumannya menarik. Pas untuk quality time di akhir pekan.”", name: "Nadia R.", initials: "NR" },
  { text: "“Pelayanan ramah, pastry-nya enak, dan interiornya bikin betah berlama-lama.”", name: "Raka P.", initials: "RP" }
];
let reviewIndex = 0;
const reviewText = document.querySelector(".review-card blockquote");
const reviewName = document.querySelector(".review-person strong");
const reviewAvatar = document.querySelector(".avatar");
const reviewCount = document.getElementById("review-count");
function showReview(index) {
  reviewIndex = (index + reviews.length) % reviews.length;
  const review = reviews[reviewIndex];
  reviewText.textContent = review.text;
  reviewName.textContent = review.name;
  reviewAvatar.textContent = review.initials;
  reviewCount.textContent = `0${reviewIndex + 1} / 0${reviews.length}`;
}
document.getElementById("prev-review").addEventListener("click", () => showReview(reviewIndex - 1));
document.getElementById("next-review").addEventListener("click", () => showReview(reviewIndex + 1));
document.getElementById("year").textContent = new Date().getFullYear();
